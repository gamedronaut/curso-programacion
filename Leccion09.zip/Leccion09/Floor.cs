using Godot;
using System;

public partial class Floor : MeshInstance3D
{
    [Export] private Node3D _cube;

    public override void _Process(double delta)
    {
        if (_cube == null) return;
        SetGlobalPosition(_cube.GetGlobalPosition() with { Y = 0 });
    }
}
