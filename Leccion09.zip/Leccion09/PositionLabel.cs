using Godot;
using System;

public partial class PositionLabel : RichTextLabel
{
    [Export] private Node3D _cube;
    [Export] private Camera3D _camera;

    public override void _Process(double delta)
    {
        if (_cube == null) return;
        
        var pos = _cube.GetGlobalPosition();
        Text = "Position" + '\n' +
               $"[color=red]x:[/color] {pos.X:F1}, " +
               $"[color=green]y:[/color] {pos.Y:F1}, " +
               $"[color=blue]z:[/color] {pos.Z:F1}";
        
        var screenPos = _camera.UnprojectPosition(_cube.GetGlobalPosition());
        var offset = (Size / 2) with { Y = Size.Y + 50f };
        SetGlobalPosition(screenPos - offset);
    }
}
